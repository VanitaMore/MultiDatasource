# spring-boot-multiple-datasource
How to configure multiple datasource in spring boot application
