package com.javatechie.multiple.ds.api.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javatechie.multiple.ds.api.book.service.BookService;
import com.javatechie.multiple.ds.api.model.book.Book;
import com.javatechie.multiple.ds.api.model.user.User;
import com.javatechie.multiple.ds.api.user.service.UserService;

@RestController
@RequestMapping("/test")
public class MyController {

	@Autowired
	UserService userService;
	@Autowired
	BookService bookService;

	@PostMapping("/insertUserData")
	public User insertUser(@RequestBody User user) {
		return userService.insertUser(user);
	}

	@PostMapping("/insertBookData")
	public Book insertBook(@RequestBody Book book) {
		return bookService.insertBook(book);
	}

	@GetMapping("/getUsers")
	public List<User> getUsers() {
		return userService.findAll();
	}

	@GetMapping("/getBooks")
	public List<Book> getBooks() {
		return bookService.findAll();
	}

}
