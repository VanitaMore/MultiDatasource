package com.javatechie.multiple.ds.api.book.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatechie.multiple.ds.api.book.repository.BookRepository;
import com.javatechie.multiple.ds.api.model.book.Book;

@Service
public class BookServiceImpl implements BookService {

	@Autowired BookRepository bookRepository;
	@Override
	public List<Book> findAll() {
		return bookRepository.findAll();
	}
	@Override
	public Book insertBook(Book book) {
		return bookRepository.save(book);
	}

	
}
